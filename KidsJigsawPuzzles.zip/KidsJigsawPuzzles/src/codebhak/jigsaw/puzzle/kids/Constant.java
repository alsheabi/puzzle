/**
 * 
 */
package codebhak.jigsaw.puzzle.kids;

/**
 * @author ThangTB
 *
 */
public class Constant {
	
	public static final String SHAREPRERENCE = "puzzles_game";
	public static final String SP_DISPLAY_GRID = "1";
	public static final String SP_EASY_PIE = "2";
	public static final String SP_ENABLE_SOUND = "3";
	public static final String SP_DISPLAY_WORDs = "4";
	public static final String SP_VIBRATE_DRAG = "5";
	public static final String SP_VIBRATE_PIE = "6";
	public static final String SP_ENABLE_WORD_SOUND = "7";
	public static final String SP_RESTART_PUZZLE = "8";
	
	public static final int ST_SUPPORT_PIE = 30;
	public static final int ST_NOSUPPORT_PIE = 10;
	
	
}
